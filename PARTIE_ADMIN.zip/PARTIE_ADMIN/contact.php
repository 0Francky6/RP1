<?php
session_start();
include 'Bdconnect.php';
$sql = "SELECT * FROM contacts";
$result = mysqli_query($bdd, $sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Messages Contact</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

    <link rel="stylesheet" href="admin.css">
    <style>
        body { font-family: 'Poppins', sans-serif; }
        .sidebar .nav-link { color: #333; }
        .sidebar .nav-link.active { font-weight: bold; color: #FF6600; }
        .admin-header { background-color: #FF6600; color: white; }
        td { vertical-align: middle; }
        .btn-supprimer { background-color: #dc3545; color: white; padding: 5px 10px; border-radius: 4px; text-decoration: none; }
        .btn-supprimer:hover { background-color: #c82333; }
    </style>
</head>
<body>

<!-- Header -->
<header class="admin-header d-flex justify-content-between align-items-center p-3">
    <h1 class="h3 m-0">Messages Contact</h1>
    <a href="logout.php" class="btn btn-danger">Déconnexion</a>
</header>

<div class="container-fluid">
    <div class="row">

        <!-- Sidebar -->
        <aside class="col-md-2 bg-light min-vh-100 p-3 sidebar">
            <ul class="nav flex-column">
                <li class="nav-item"><a class="nav-link" href="index.php">Accueil</a></li>
                <li class="nav-item"><a class="nav-link" href="voitures.php">Voitures</a></li>
                <li class="nav-item"><a class="nav-link" href="demandes.php">Demandes d'essai</a></li>
                <li class="nav-item"><a class="nav-link" href="services.php">Services</a></li>
                <li class="nav-item"><a class="nav-link active" href="contact.php">Contact</a></li>
            </ul>
        </aside>

        <!-- Main content -->
        <main class="col-md-10 p-4">
            <?php if(isset($_SESSION['message'])): ?>
                <div class="alert alert-<?= $_SESSION['message_type'] ?> alert-dismissible fade show" role="alert">
                    <?= $_SESSION['message'] ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php
                unset($_SESSION['message']);
                unset($_SESSION['message_type']);
                ?>
            <?php endif; ?>

            <?php if(mysqli_num_rows($result) > 0): ?>
                <div class="table-responsive">
                    <table id="contactTable" class="table table-bordered table-striped align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th>Nom</th>
                                <th>Adresse</th>
                                <th>Email</th>
                                <th>Message</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php while($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['nom'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['adresse'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['email'] ?? '') ?></td>
                                <td><?= htmlspecialchars(mb_strimwidth($row['messages'] ?? '', 0, 80, "...")) ?></td>
                                <td>
                                    <a href="supprimer_contact.php?idcontact=<?= $row['idcontact'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Voulez-vous vraiment supprimer ce message ?');">Supprimer</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p>Aucun message trouvé.</p>
            <?php endif; ?>

        </main>
    </div>
</div>

<!-- Scripts JS -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function() {
    $('#contactTable').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.13.6/i18n/fr-FR.json"
        }
    });
});
</script>

</body>
</html>
