<?php
session_start();
include("Bdconnect.php");

// Vérifie qu'on reçoit bien une requête POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Récupération sécurisée des valeurs du formulaire
    $id         = intval($_POST['id']);
    $marque     = mysqli_real_escape_string($bdd, $_POST['marque']);
    $modele     = mysqli_real_escape_string($bdd, $_POST['modele']);
    $prix       = mysqli_real_escape_string($bdd, $_POST['prix']);
    $description= mysqli_real_escape_string($bdd, $_POST['description']);
    $image      = mysqli_real_escape_string($bdd, $_POST['image']);

    // Requête SQL pour mettre à jour la voiture
    $sql = "UPDATE voiture SET 
                marque = '$marque',
                modele = '$modele',
                prix = '$prix',
                description = '$description',
                image = '$image'
            WHERE id = $id";

    if (mysqli_query($bdd, $sql)) {
        $_SESSION['message'] = "✅ Voiture modifiée avec succès !";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "❌ Erreur : " . mysqli_error($bdd);
        $_SESSION['message_type'] = "danger"; // pour bootstrap alert
    }
}

// Redirige toujours vers voitures.php après traitement
header("Location: voitures.php");
exit;
?>
