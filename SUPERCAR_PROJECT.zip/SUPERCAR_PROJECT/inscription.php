<?php
// Connexion à la base de données
$serveur = "localhost";
$utilisateur = "root";  
$motDePasse = "";        
$baseDeDonnees = "supercar"; // le nom de la base de données

$connexion = new mysqli($serveur, $utilisateur, $motDePasse, $baseDeDonnees);

// Vérifier si la connexion fonctionne
if ($connexion->connect_error) {
    die("Erreur de connexion : " . $connexion->connect_error);
}

// Vérifier si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom             =  $_POST["nom"];
    $prenom          =  $_POST["prenom"];
    $email           =  $_POST["email"];
    $nom_utilisateur =  $_POST["nom_utilisateur"];
    $mot_de_passe    =  $_POST["mot_de_passe"]; //PASSWORD_BCRYPT); // Sécuriser le mot de passe

    // Insérer les données dans la table "utilisateurs"
    $sql = "INSERT INTO utilisateur (nom, prenom, email, nom_utilisateur, mot_de_passe) 
            VALUES ('$nom', '$prenom', '$email', '$nom_utilisateur', '$mot_de_passe')";

    if ($connexion->query($sql) === TRUE) {
        echo "Inscription réussie !";
    } else {
        echo "Erreur : " . $connexion->error;
    }
}

// Fermer la connexion
$connexion->close();
?>
