<?php
// définir vos paramètres de connexion

// nom du serveur
$host = "localhost";
// nom utilisateur
$login = "root";
// mot de passe
$pass = "";
// nom de la base de données
$dbname = "supercar";

// créer la connexion avec la base de données
$bdd = mysqli_connect($host, $login, $pass, $dbname);

// vérification de la connexion avec la BD
if (!$bdd) {
    // afficher un message d'erreur avec concaténation correcte
    echo "Connexion non-reussie à MySQL: " . mysqli_connect_error();
} else {
    // message de connexion réussi (à ne pas afficher en production)
    // echo "Connexion reussie à MySQL"; // Il est recommandé de ne pas afficher ce genre de message en production
}

// changer le jeu de caractères à utf8
mysqli_set_charset($bdd, "utf8");
?>
