<?php
include ("Bdconnect.php");

$ID = $_GET["idcontact"]; 

      // Requête SQL corrigée
      $supprimer = "DELETE FROM contacts 
      WHERE idcontact = $ID";

      // Exécution de la requête
      mysqli_query($bdd, $supprimer);
      mysqli_close($bdd);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>suppression</title>
</head>
<body>
    <P>suppression réussie</P> <a href="index.php">Retour au tableau de bord </a>
</body>
</html>