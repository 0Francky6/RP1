<?php
session_start();
include("Bdconnect.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nom = mysqli_real_escape_string($bdd, $_POST['Nom']);
    $mdp = $_POST['mdp'];

    // Vérifie si l'admin existe
    $query = "SELECT * FROM admins WHERE username = '$nom' LIMIT 1";
    $result = mysqli_query($bdd, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $admin = mysqli_fetch_assoc($result);

        // ⚠️ Comparaison directe (mot de passe en clair)
        if ($mdp === $admin['password']) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_name'] = $admin['username'];

            header("Location: index.php");
            exit();
        } else {
            $_SESSION['login_error'] = "❌ Mot de passe incorrect.";
        }
    } else {
        $_SESSION['login_error'] = "❌ Utilisateur non trouvé.";
    }

    header("Location: connexion_admin.php");
    exit();
}
