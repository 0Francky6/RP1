<?php
include("Bdconnect.php");

$marque = isset($_GET['marque']) ? mysqli_real_escape_string($bdd, $_GET['marque']) : '';

if (empty($marque)) {
    echo "<h2 style='color:red'>❌ Aucune marque spécifiée.</h2>";
    exit;
}

$sql = "SELECT * FROM voiture WHERE marque = '$marque'";
$result = mysqli_query($bdd, $sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Voitures <?= htmlspecialchars($marque) ?></title>
    
    <style>
        body {
            
            background-color: #f8f8f8;
            padding: 20px;
            text-align: center;
        }

        .car {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            padding: 15px;
            margin: 20px auto;
            max-width: 400px;
        }

        .car img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 10px;
        }

        h1 {
            color: #333;
        }
    </style>
</head>
<body>

<h1>Modèles <?= htmlspecialchars($marque) ?></h1>

<?php
if (mysqli_num_rows($result) > 0) {
    while ($car = mysqli_fetch_assoc($result)) {
?>
        <div class="car">
            <h2><?= htmlspecialchars($car['modele']) ?> - <?= number_format($car['prix'], 2, ',', ' ') ?> €</h2>
            <img src="<?= htmlspecialchars($car['image']) ?>" alt="<?= htmlspecialchars($car['modele']) ?>">
            <p><?= nl2br(htmlspecialchars($car['description'])) ?></p>
        </div>
<?php
    }
} else {
    echo "<p>Aucune voiture trouvée pour la marque <strong>" . htmlspecialchars($marque) . "</strong>.</p>";
}
?>
 <script src="script.js"></script>
</body>
</html>
