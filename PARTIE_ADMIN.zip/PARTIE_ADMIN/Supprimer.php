<?php
include("Bdconnect.php");

// Démarre la session pour utiliser les variables de session
session_start();

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM voiture WHERE id = $id";
    if (mysqli_query($bdd, $sql)) {
        // Si la suppression réussie, on met un message dans la session
        $_SESSION['message'] = "La voiture a bien été supprimée.";
    } else {
        // Si la suppression échoue, on met un message d'erreur dans la session
        $_SESSION['message'] = "Erreur lors de la suppression de la voiture.";
    }
}

// Rediriger vers la page des voitures
header("Location: voitures.php");
exit;
?>
