<?php
include("Bdconnect.php");

if (isset($_GET['id'], $_GET['statut'])) {
    $id = (int) $_GET['id'];
    $statut = mysqli_real_escape_string($bdd, $_GET['statut']);

    $sql = "UPDATE demandes_essai SET statut = '$statut' WHERE id = $id";
    mysqli_query($bdd, $sql);
}

header("Location: Demandes.php"); // Remplace par le bon nom de fichier
exit();
