<?php
session_start();
include("Bdconnect.php");

// Récupération des voitures
$result = mysqli_query($bdd, "SELECT * FROM voiture");
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Gestion des Voitures</title>

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

  <!-- CSS personnalisé -->
  <link rel="stylesheet" href="admin.css">

  <style>
    body { 
      font-family: 'Poppins', sans-serif; 
    }
    .sidebar .nav-link {
       color: #333;
       }
    .sidebar .nav-link.active { 
      font-weight: bold; 
      color: #FF6600; 
    }
    .card { 
      border-radius: 10px; 
      box-shadow: 0 4px 8px rgba(0,0,0,0.1); 
    }
    .admin-header { 
      background-color: #FF6600; 
      color: white; 
    }
    td img { 
      max-width: 100px; 
      height: auto; 
    }
  </style>
</head>
<body>

<!-- Header -->
<header class="admin-header d-flex justify-content-between align-items-center p-3">
  <h1 class="h3 m-0">Gestion des Voitures</h1>
  <a href="logout.php" class="btn btn-danger">Déconnexion</a>
</header>

<!-- Container principal -->
<div class="container-fluid">
  <div class="row">

    <!-- Sidebar -->
    <aside class="col-md-2 bg-light min-vh-100 p-3 sidebar">
      <ul class="nav flex-column">
        <li class="nav-item"><a class="nav-link" href="index.php">Accueil</a></li>
        <li class="nav-item"><a class="nav-link active" href="voitures.php">Voitures</a></li>
        <li class="nav-item"><a class="nav-link" href="demandes.php">Demandes d'essai</a></li>
        <li class="nav-item"><a class="nav-link" href="services.php">Services</a></li>
        <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
      </ul>
    </aside>

    <!-- Main content -->
    <main class="col-md-10 p-4">
      <?php if(isset($_SESSION['message'])): ?>
<?php 
  $type = $_SESSION['message_type'] ?? 'success'; // valeur par défaut si message_type n'existe pas
?>
<div class="alert alert-<?= $type ?> alert-dismissible fade show" role="alert">
    <?= $_SESSION['message'] ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
  <?php
  // On supprime le message pour qu’il n’apparaisse plus après un refresh
  unset($_SESSION['message']);
  unset($_SESSION['message_type']);
  ?>
<?php endif; ?>


      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Liste des Voitures</h2>
        <!-- Bouton Ajouter en modal -->
        <button type="button" class="btn btn-success btn-lg" data-bs-toggle="modal" data-bs-target="#modalAjouter">
          ➕ Ajouter une voiture
        </button>
      </div>

      <!-- Modal Ajouter -->
      <div class="modal fade" id="modalAjouter" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
          <div class="modal-content">
            <form method="post" action="ajouter.php">
              <div class="modal-header bg-success text-white">
                <h5 class="modal-title">Ajouter une voiture</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body">
                <div class="row g-3">
                  <div class="col-md-6">
                    <label class="form-label">Marque</label>
                    <input type="text" name="marque" class="form-control" required>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label">Modèle</label>
                    <input type="text" name="modele" class="form-control" required>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label">Prix (€)</label>
                    <input type="text" name="prix" class="form-control" required>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label">Image (chemin)</label>
                    <input type="text" name="image" class="form-control" required>
                  </div>
                  <div class="col-12">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="4" required></textarea>
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                <button type="submit" class="btn btn-success">Ajouter</button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <!-- Table des voitures -->
      <?php if (mysqli_num_rows($result) == 0): ?>
        <p class="text-danger">Aucune voiture enregistrée.</p>
      <?php else: ?>
        <div class="table-responsive">
          <table class="table table-bordered table-striped align-middle">
            <thead class="table-dark">
              <tr>
                <th>ID</th>
                <th>Marque</th>
                <th>Modèle</th>
                <th>Prix (€)</th>
                <th>Image</th>
                <th>Description</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php while ($voiture = mysqli_fetch_assoc($result)) { ?>
                <tr>
                  <td><?= $voiture['id'] ?></td>
                  <td><?= $voiture['marque'] ?></td>
                  <td><?= $voiture['modele'] ?></td>
                  <td><?= number_format($voiture['prix'], 2, ',', ' ') ?> €</td>
                  <td><img src="../<?= $voiture['image'] ?>" alt="voiture"></td>
                  <td><?= mb_strimwidth($voiture['description'], 0, 80, "...") ?></td>
                  <td class="d-flex gap-2">
                    <!-- Modifier en modal -->
                    <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modalModifier<?= $voiture['id'] ?>">
                      Modifier
                    </button>

                    <!-- Modal Modification -->
                    <div class="modal fade" id="modalModifier<?= $voiture['id'] ?>" tabindex="-1" aria-hidden="true">
                      <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content">
                          <form method="post" action="modifier_voiture.php">
                            <div class="modal-header bg-warning text-dark">
                              <h5 class="modal-title">Modifier la voiture</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                              <input type="hidden" name="id" value="<?= $voiture['id'] ?>">
                              <div class="row g-3">
                                <div class="col-md-6">
                                  <label class="form-label">Marque</label>
                                  <input type="text" name="marque" class="form-control" value="<?= htmlspecialchars($voiture['marque']) ?>" required>
                                </div>
                                <div class="col-md-6">
                                  <label class="form-label">Modèle</label>
                                  <input type="text" name="modele" class="form-control" value="<?= htmlspecialchars($voiture['modele']) ?>" required>
                                </div>
                                <div class="col-md-6">
                                  <label class="form-label">Prix (€)</label>
                                  <input type="text" name="prix" class="form-control" value="<?= htmlspecialchars($voiture['prix']) ?>" required>
                                </div>
                                <div class="col-md-6">
                                  <label class="form-label">Image (chemin)</label>
                                  <input type="text" name="image" class="form-control" value="<?= htmlspecialchars($voiture['image']) ?>" required>
                                </div>
                                <div class="col-12">
                                  <label class="form-label">Description</label>
                                  <textarea name="description" class="form-control" rows="3" required><?= htmlspecialchars($voiture['description']) ?></textarea>
                                </div>
                              </div>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Fermer</button>
                              <button type="submit" class="btn btn-warning">Modifier</button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>

                    <!-- Supprimer -->
                    <a href="supprimer.php?id=<?= $voiture['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Voulez-vous vraiment supprimer cette voiture ?');">
                      Supprimer
                    </a>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>

    </main>
  </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
