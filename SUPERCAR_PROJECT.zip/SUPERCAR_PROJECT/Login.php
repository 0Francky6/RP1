<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

include('Bdconnect.php'); 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $mot_de_passe = $_POST['mot_de_passe'];

    $sql = "SELECT * FROM utilisateur WHERE email = '$email' AND mot_de_passe = '$mot_de_passe'";
    $result = $bdd->query($sql);
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $_SESSION['user_id'] = $user['id'];
        header("Location: dashboard.php");
        exit(); 
    } else {
        $error_message = "Identifiants incorrects";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">


  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet" />

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

  <!-- Custom CSS -->
  <link rel="stylesheet" href="styles.css" />
    

    <title>Connexion - SUPERCARS</title>
    <style>
        /* ====== GLOBAL ====== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        /* ====== IMAGE DE FOND ====== */
        body {
            background: url('IMAGES/cn.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

      

        /* ====== CONTAINER FORMULAIRE (DÉGRADÉ) ====== */
        .container {
            background: linear-gradient(135deg, white, #ff5733);
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
            text-align: center;
            width: 350px;
            margin-top: 80px;
        }

        /* ====== Titre ====== */
        h2 {
            color: #333;
            font-size: 24px;
            margin-bottom: 20px;
        }

        /* ====== Message d'erreur ====== */
        .error-message {
            color: red;
            font-size: 14px;
            margin-bottom: 15px;
        }

        /* ====== Champs du formulaire ====== */
        label {
            display: block;
            font-weight: bold;
            margin: 10px 0 5px;
            color: #444;
        }

        input {
            width: 100%;
            padding: 10px;
            border: 2px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s ease-in-out;
        }

        input:focus {
            border-color: #ff5733;
            outline: none;
            box-shadow: 0 0 10px rgba(255, 87, 51, 0.3);
        }

        /* ====== Bouton ====== */
        button {
            width: 100%;
            padding: 12px;
            background: #ff5733;
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s;
            margin-top: 15px;
        }

        button:hover {
            background: #d9461e;
        }

        /* ====== Responsive ====== */
        @media (max-width: 400px) {
            .container {
                width: 90%;
            }
        }

        .register-link {
            font-size: 14.5px;
            text-align: center;
            margin: 20px 0 15px;
        }
        .register-link p a {
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }
        .register-link p a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<!-- ====== HEADER ====== -->
 <header class="header">
  <div class="header-left">
    <a href="#" class="logo">SUPERCARS</a>
  </div>

  <!-- Bouton burger -->
  <div class="menu-toggle" id="menu-toggle">
    <i class="fas fa-bars"></i>
  </div>

  <nav class="navbar" id="navbar">
    <a href="index.html">Accueil</a>
    <a href="Voitures.html">Voitures</a>
    <a href="demande_essai.php">Demande d'essai</a>
    <a href="Service.php">Services</a>
    <a href="Contact.html">Contact</a>
  </nav>

  <div class="auth-links">
    <a href="Login.php">Se connecter</a>
    <a href="inscription.html">S'inscrire</a>
  </div>
</header>

<!-- ====== CONTAINER FORMULAIRE ====== -->
<div class="container">
    <h2>Connexion</h2>

    <?php if (isset($error_message)): ?>    
        <p class="error-message"><?php echo $error_message; ?></p>
    <?php endif; ?>

    <form action="login.php" method="POST">
        <label for="email"></label>
        <input type="email" name="email" placeholder="Email" required>

        <label for="mot_de_passe"></label>
        <input type="password" name="mot_de_passe" placeholder="Mot de passe"  required>

        <button type="submit">Se connecter</button>
        <div class="register-link">
                <p>Vous n'avez pas de compte ? <a href="inscription.html">S'inscrire</a></p>
            </div>
    </form>
</div>
 <script src="script.js"></script>

</body>
</html>
