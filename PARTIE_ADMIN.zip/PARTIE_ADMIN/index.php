<?php
session_start();
include("Bdconnect.php");
if (!isset($_SESSION['admin_id'])) {
    header("Location: connexion_admin.php");
    exit();
}


// Comptages
$voitures_count = mysqli_fetch_assoc(mysqli_query($bdd, "SELECT COUNT(*) AS total FROM voiture"))['total'];
$services_count = mysqli_fetch_assoc(mysqli_query($bdd, "SELECT COUNT(*) AS total FROM service_car"))['total'];
$demandes_count = mysqli_fetch_assoc(mysqli_query($bdd, "SELECT COUNT(*) AS total FROM demandes_essai"))['total'];
$users_count    = mysqli_fetch_assoc(mysqli_query($bdd, "SELECT COUNT(*) AS total FROM utilisateur"))['total'];

// Dernières voitures et services
$latest_cars = mysqli_query($bdd, "SELECT id, marque, modele, prix FROM voiture ORDER BY id DESC");
$latest_services = mysqli_query($bdd, "SELECT id, nom, description FROM service_car ORDER BY id DESC");

// Graphique demandes par mois
$demandes_par_mois = mysqli_query($bdd, "
    SELECT MONTH(date_demande) AS mois, COUNT(*) AS total 
    FROM demandes_essai 
    WHERE YEAR(date_demande) = YEAR(CURDATE())
    GROUP BY MONTH(date_demande)
    ORDER BY mois
");

$mois_labels = [];
$demandes_data = [];
while($row = mysqli_fetch_assoc($demandes_par_mois)){
    $mois_labels[] = $row['mois'];
    $demandes_data[] = $row['total'];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">

<title>Dashboard Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="admin.css">
<!-- DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">

<style>
body { 
    font-family: 'Poppins', sans-serif; 
}

.sidebar { 
    min-height: 100vh;
 }

.sidebar .nav-link { 
    color: #333; 
}

.sidebar .nav-link.active { 
    font-weight: bold; 
    color: #FF6600; 
}

.card { 
    border-radius: 10px; 
    box-shadow: 0 4px 8px rgba(0,0,0,0.1); 
}
.admin-header { 
    background-color: #FF6600; 
    color: white; 
}

@media (max-width: 768px) {
    .sidebar { 
        position: fixed; 
        top: 0; 
        left: -250px; 
        width: 250px; 
        z-index: 1040; 
        transition: 0.3s; 
    }

    .sidebar.show {
         left: 0; 
        }
    main { 
        margin-left: 0 !important; }
}
</style>
</head>
<body>

<header class="admin-header d-flex justify-content-between align-items-center p-3">
    <h1 class="h3 m-0">Tableau de bord Admin</h1>
    <div>
        <button class="btn btn-light d-md-none" id="sidebarToggle">☰</button>
        <a href="logout.php" class="btn btn-danger">Déconnexion</a>
    </div>
</header>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <aside class="col-md-2 bg-light p-3 sidebar" id="sidebar">
            <ul class="nav flex-column">
                <li class="nav-item"><a class="nav-link active" href="index.php">Accueil</a></li>
                <li class="nav-item"><a class="nav-link" href="voitures.php">Voitures</a></li>
                <li class="nav-item"><a class="nav-link" href="Demandes.php">Demandes d'essai</a></li>
                <li class="nav-item"><a class="nav-link" href="Services.php">Services</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
            </ul>
        </aside>

        <!-- Main content -->
        <main class="col-md-10 p-4">
            <h2 class="mb-4">Bienvenue, Admin !</h2>

            <!-- Cards récap -->
            <div class="row g-3 mb-4">
                <div class="col-md-3">
                    <div class="card text-center p-3"><div class="card-body"><h5 class="card-title">Voitures</h5><p class="card-text fs-4"><?= $voitures_count ?></p></div></div>
                </div>
                <div class="col-md-3">
                    <div class="card text-center p-3"><div class="card-body"><h5 class="card-title">Services</h5><p class="card-text fs-4"><?= $services_count ?></p></div></div>
                </div>
                <div class="col-md-3">
                    <div class="card text-center p-3"><div class="card-body"><h5 class="card-title">Demandes</h5><p class="card-text fs-4"><?= $demandes_count ?></p></div></div>
                </div>
                <div class="col-md-3">
                    <div class="card text-center p-3"><div class="card-body"><h5 class="card-title">Utilisateurs</h5><p class="card-text fs-4"><?= $users_count ?></p></div></div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="mb-4">
                <a href="voitures.php" class="btn btn-success me-2">Ajouter / Gérer Voitures</a>
                <a href="Services.php" class="btn btn-primary me-2">Ajouter / Gérer Services</a>
                <a href="Demandes.php" class="btn btn-warning">Voir les demandes</a>
            </div>

            <!-- Tableau voitures -->
            <h4>Voitures</h4>
            <div class="table-responsive mb-4">
                <table id="carsTable" class="display table table-striped table-bordered">
                    <thead><tr><th>ID</th><th>Marque</th><th>Modèle</th><th>Prix</th></tr></thead>
                    <tbody>
                        <?php while($car = mysqli_fetch_assoc($latest_cars)): ?>
                        <tr>
                            <td><?= $car['id'] ?></td>
                            <td><?= htmlspecialchars($car['marque']) ?></td>
                            <td><?= htmlspecialchars($car['modele']) ?></td>
                            <td><?= number_format($car['prix'],2,',',' ') ?> €</td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

            <!-- Tableau services -->
            <h4>Services</h4>
            <div class="table-responsive mb-4">
                <table id="servicesTable" class="display table table-striped table-bordered">
                    <thead><tr><th>ID</th><th>Nom</th><th>Description</th></tr></thead>
                    <tbody>
                        <?php while($service = mysqli_fetch_assoc($latest_services)): ?>
                        <tr>
                            <td><?= $service['id'] ?></td>
                            <td><?= htmlspecialchars($service['nom']) ?></td>
                            <td><?= mb_strimwidth($service['description'],0,50,'...') ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

            <!-- Graphique demandes -->
            <h4>Demandes d'essai par mois (<?= date('Y') ?>)</h4>
            <canvas id="demandesChart" height="100"></canvas>

        </main>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.getElementById('sidebarToggle').addEventListener('click', function() {
    document.getElementById('sidebar').classList.toggle('show');
});

// Initialiser DataTables
$(document).ready(function() {
    $('#carsTable').DataTable({ "pageLength": 5 });
    $('#servicesTable').DataTable({ "pageLength": 5 });
});

// Chart.js pour les demandes
const ctx = document.getElementById('demandesChart').getContext('2d');
const demandesChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?= json_encode($mois_labels) ?>,
        datasets: [{
            label: 'Demandes',
            data: <?= json_encode($demandes_data) ?>,
            backgroundColor: '#FF6600'
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: false },
            title: { display: true, text: 'Demandes par mois' }
        }
    }
});
</script>

</body>
</html>
