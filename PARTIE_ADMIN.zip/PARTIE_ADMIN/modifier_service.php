<?php
session_start();
include("Bdconnect.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = intval($_POST['id']);
    $nom = mysqli_real_escape_string($bdd, $_POST['nom']);
    $description = mysqli_real_escape_string($bdd, $_POST['description']);
    $details = mysqli_real_escape_string($bdd, $_POST['details']);

    $imageName = $_POST['old_image'] ?? '';
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0){
        $imageName = time().'_'.$_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], '../IMAGES/'.$imageName);
    }

    $sql = "UPDATE service_car SET nom='$nom', description='$description', details='$details', image='$imageName' WHERE id=$id";

    if (mysqli_query($bdd, $sql)) {
        $_SESSION['message'] = "✅ Service modifié avec succès !";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "❌ Erreur : " . mysqli_error($bdd);
        $_SESSION['message_type'] = "danger";
    }

    header("Location: services.php");
    exit;
}
?>
