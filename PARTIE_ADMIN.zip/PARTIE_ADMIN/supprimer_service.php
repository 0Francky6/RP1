<?php
session_start();
include("Bdconnect.php");

if(isset($_GET['id'])){
    $id = intval($_GET['id']);
    mysqli_query($bdd, "DELETE FROM service_car WHERE id=$id");

    $_SESSION['message'] = "✅ Service supprimé avec succès !";
    $_SESSION['message_type'] = "success";
}

header("Location: services.php");
exit;
?>
