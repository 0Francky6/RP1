<?php
// Inclure la connexion à la base
include 'Bdconnect.php';

// Récupérer tous les services
$query = "SELECT * FROM service_car";
$result = mysqli_query($bdd, $query);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SUPERCARS - Services</title>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <!-- Fichier CSS principal -->
    <link rel="stylesheet" href="styles.css?v=1.0">

    <!-- Styles internes optionnels (si nécessaire pour corrections rapides) -->
    <style>
        /* Exemple pour s'assurer que le CSS est chargé */
        body { font-family: 'Poppins', sans-serif; }
    </style>

    <style>
        /* Bouton "Voir plus" déjà défini dans ton CSS existant */
        .btn {
            display: inline-block;
            background: #ff5733;
            color: #fff;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            font-size: 16px;
            border: none;
            transition: 0.3s;
        }
        .btn:hover { background: #e64b1f; }

        .hidden-content {
            display: none;
            margin-top: 10px;
            padding: 10px;
            background: #f9f9f9;
            border-left: 4px solid #ff5733;
        }
    </style>
</head>
<body>
    <div class="top-background"></div>
    <header class="header">
    <div class="header-left">
      <a href="#" class="logo">SUPERCARS</a>
    </div>
    <nav class="navbar">
      <a href="index.html">Accueil</a>
      <a href="Voitures.html">Voitures</a>
      <a href="demande_essai.php">Demande d'essai</a>
      <a href="Service.php">Services</a>
      <a href="Contact.html">Contact</a>
    </nav>
    <div class="auth-links">
      <a href="Login.php">Se connecter</a>
      <a href="inscription.php">S'inscrire</a>
      <!--  <i class="fa-solid fa-lock"></i> Admin
      </a>-->
    </div>
  </header>
  

    <div class="banner">NOS SERVICES</div>

    <?php while ($service = mysqli_fetch_assoc($result)): ?>
    <section class="service-section">
        <img src="<?php echo $service['image']; ?>" alt="<?php echo $service['nom']; ?>">
        <div class="service-info">
            <h2><?php echo $service['nom']; ?></h2>
            <p><?php echo $service['description']; ?></p>

            <?php if (!empty($service['details'])): ?>
            <?php
                // Séparer les sections A et B
                $details = explode("\n", $service['details']);
            ?>
            <button class="btn" onclick="this.nextElementSibling.classList.toggle('show')">Voir plus</button>
            <div class="hidden-content">
                <?php foreach ($details as $d): ?>
                    <?php
                        $d = trim($d);
                        if (!empty($d)) {
                            // Séparer titre et liste
                            if (strpos($d, ':') !== false) {
                                list($title, $items) = explode(':', $d, 2);
                                $itemsArray = explode(',', $items);
                                echo "<h4>".trim($title)."</h4><ul>";
                                foreach ($itemsArray as $item) {
                                    echo "<li>".trim($item)."</li>";
                                }
                                echo "</ul>";
                            } else {
                                echo "<p>$d</p>";
                            }
                        }
                    ?>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </section>
    <?php endwhile; ?>

    <footer>
        <div class="footer-bottom">
            <p>&copy; 2025-2028 Supercars.fr — Tous droits réservés. Réalisation & design MCCI SIO.</p>
            <a href="Mentions.php">Mentions légales</a>
            <a href="politique.php">Politique de confidentialité</a>
            <a href="conditions.php">Conditions générales</a>
        </div>
        <div class="footer-section socials-bottom">
            <h3>Suivez-nous</h3>
            <div class="socials">
                <a href="https://www.facebook.com" target="_blank"><img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/facebook.svg" alt="Facebook" /></a>
                <a href="https://www.twitter.com" target="_blank"><img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/twitter.svg" alt="Twitter" /></a>
                <a href="https://www.instagram.com" target="_blank"><img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/instagram.svg" alt="Instagram" /></a>
            </div>
        </div>
    </footer>

</body>
</html>














