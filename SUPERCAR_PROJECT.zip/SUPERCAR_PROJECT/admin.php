<?php
session_start();
include("Bdconnect.php");

$erreur = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Comparaison directe avec mot de passe en clair (pas sécurisé en prod)
    $query = "SELECT * FROM admins WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($bdd, $query);

    if ($result && mysqli_num_rows($result) == 1) {
        $admin = mysqli_fetch_assoc($result);
        $_SESSION["admin"] = $admin["username"];
        header("Location: ../PARTIE_ADMIN/dashboard.php");
        exit();
    } else {
        $erreur = "Nom d'utilisateur ou mot de passe incorrect.";
    }
}
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion Admin</title>
    <style>
        *{
            align:center;
        }
    </style>
</head>
<body>
    <h2>Connexion Admin</h2>
    <form method="post" align="center">
        <input type="text" name="username" placeholder="Nom d'utilisateur" required><br>
        <input type="password" name="password" placeholder="Mot de passe" required><br>
        <button type="submit">Se connecter</button>
    </form>
    <?php if ($erreur) echo "<p style='color:red;'>$erreur</p>"; ?>
</body>
</html>
