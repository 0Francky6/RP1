<?php
session_start();
$error = null;

// Récupérer le message d'erreur depuis la session
if (isset($_SESSION['login_error'])) {
    $error = $_SESSION['login_error'];
    unset($_SESSION['login_error']);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
<title>Connexion Admin</title>
<style>
* {
    box-sizing: border-box; /* Inclut padding et border dans la largeur */
    margin: 0;
    padding: 0;
}

body {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: linear-gradient(135deg, #1f1c2c, #928dab);
    font-family: 'Poppins', sans-serif;
}

.wrapper {
    width: 400px;
    padding: 50px 30px;
    background: rgba(255,255,255,0.12);
    border: 2px solid rgba(255,255,255,0.2);
    backdrop-filter: blur(15px);
    border-radius: 15px;
    color: #fff;
    box-shadow: 0 8px 25px rgba(0,0,0,0.3);
}

.wrapper h1 {
    text-align: center;
    margin-bottom: 30px;
    font-size: 32px;
    letter-spacing: 1px;
}

.input-box {
    position: relative;
    margin-bottom: 25px;
}

.input-box input {
    width: 100%;
    padding: 15px 45px 15px 15px;
    border-radius: 40px;
    border: 2px solid rgba(255,255,255,0.2);
    background: transparent;
    color: #fff;
    font-size: 16px;
    outline: none;
    transition: 0.3s;
}

.input-box input:focus {
    border-color: #fff;
    box-shadow: 0 0 8px rgba(255,255,255,0.3);
}

.input-box i {
    position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: rgba(255,255,255,0.7);
    font-size: 18px;
}

.btn {
    width: 100%;
    padding: 15px;
    border: none;
    border-radius: 40px;
    background: #fff;
    color: #333;
    font-weight: 600;
    cursor: pointer;
    font-size: 16px;
    transition: 0.3s;
}

.btn:hover {
    background: #f0f0f0;
}

.error {
    margin: 15px 0;
    padding: 12px;
    background: rgba(255,0,0,0.2);
    border: 1px solid red;
    border-radius: 8px;
    text-align: center;
    color: #ff8080;
    font-weight: 500;
}
</style>
</head>
<body>
<div class="wrapper">
    <form action="login.php" method="POST">
        <h1>Connexion Admin</h1>

        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="input-box">
            <input type="text" name="Nom" placeholder="Nom d'utilisateur" required>
            <i class='bx bxs-user'></i>
        </div>

        <div class="input-box">
            <input type="password" name="mdp" placeholder="Mot de passe" required>
            <i class='bx bxs-lock-alt'></i>
        </div>

        <button type="submit" class="btn">Se connecter</button>
    </form>
</div>
</body>
</html>
