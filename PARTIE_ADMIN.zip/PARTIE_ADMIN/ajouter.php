<?php
// Connexion à la base de données
include("Bdconnect.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Récupération des valeurs envoyées par le formulaire
    $marque      = mysqli_real_escape_string($bdd, $_POST['marque']);
    $modele      = mysqli_real_escape_string($bdd, $_POST['modele']);
    $prix        = mysqli_real_escape_string($bdd, $_POST['prix']);
    $description = mysqli_real_escape_string($bdd, $_POST['description']);
    $image       = mysqli_real_escape_string($bdd, $_POST['image']);

    // Requête SQL pour insérer la voiture
    $sql = "INSERT INTO voiture (marque, modele, prix, description, image) 
            VALUES ('$marque', '$modele', '$prix', '$description', '$image')";

    if (mysqli_query($bdd, $sql)) {
        // Redirection vers voitures.php après ajout
        header("Location: voitures.php?ajout=success");
        exit();
    } else {
        // Redirection avec message d'erreur
        header("Location: voitures.php?ajout=error");
        exit();
    }
} else {
    // Si l'utilisateur accède directement à ce fichier sans POST
    header("Location: voitures.php");
    exit();
}
?>
