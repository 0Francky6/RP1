<?php
// Connexion à la base de données
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'supercar';

$conn = new mysqli($host, $username, $password, $database);

// Vérifie la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Requête pour récupérer les voitures de la marque Toyota
$sql = "SELECT * FROM voiture WHERE marque = 'Toyota'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
   <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toyota - Supercars</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            text-align: center;
            background-color: #f8f8f8;
        }

       

        .brand.toyota {
            background-color: white;
            padding: 40px 20px;
            margin-bottom: 60px;
        }

        .brand.toyota h1 {
            font-size: 32px;
            margin-bottom: 15px;
            color: #222;
        }

        .brand.toyota p {
            font-size: 18px;
            margin-bottom: 30px;
            color: #555;
        }

        .car-models {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            justify-content: center;
        }

        .car-card {
            background-color: #fff;
            width: 500px;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            margin-bottom: 30px;
        }

        .car-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
        }

        .car-card img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            border-bottom: 2px solid #f5f5f5;
        }

        .car-card h4 {
            font-size: 24px;
            color: #222;
            text-align: center;
            margin: 15px 0;
        }

        .car-card p {
            font-size: 16px;
            color: #666;
            padding: 0 15px;
            margin-bottom: 20px;
        }

        .car-card a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #ff5733;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            text-align: center;
        }

        .car-card a:hover {
            background-color: #e8491d;
        }

        

        .socials-bottom img {
            width: 24px;
            height: 24px;
            margin: 0 5px;
        }
    </style>
</head>
<body>

<header class="header">
    <a href="#" class="logo">SUPERCARS</a>
    <nav class="navbar">
        <a href="index.html">Accueil</a>
        <a href="Voitures.html">Voitures</a>
        <a href="demande_essai.php">Demande d'essai</a>
        <a href="Service.php">Services</a>
        <a href="Contact.html">Contact</a>
    </nav>
    <div class="auth-links">
        <a href="Login.php">Se connecter</a>
        <a href="inscription.html">S'inscrire</a>
    </div>
</header>

<section class="brand toyota">
    <h1>Toyota</h1>
    <div class="car-models">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="car-card">';
                echo '<h4>' . htmlspecialchars($row['modele']) . '</h4>';
                echo '<img src="' . htmlspecialchars($row['image']) . '" alt="' . htmlspecialchars($row['modele']) . '">';
                echo '<p>' . htmlspecialchars($row['description']) . '</p>';
                echo '<p><strong>PRIX: ' . number_format($row['prix'], 2, ',', ' ') . ' €</strong></p>';
                echo '</div>';
            }
        } else {
            echo "<p>Aucune voiture Toyota disponible pour le moment.</p>";
        }
        ?>
    </div>
</section>

<footer>
    <div class="footer-bottom">
        <p>&copy; 2025-2028 Supercars.fr — Tous droits réservés. Réalisation & design MCCI SIO.</p>
        <a href="Mentions.html">Mentions légales</a>
        <a href="politique.html">Politique de confidentialité</a>
        <a href="conditions.html">Conditions générales</a>
    </div>
    <div class="footer-section socials-bottom">
        <h3>Suivez-nous</h3>
        <div class="socials">
            <a href="https://www.facebook.com" target="_blank"><img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/facebook.svg" alt="Facebook"></a>
            <a href="https://www.twitter.com" target="_blank"><img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/twitter.svg" alt="Twitter"></a>
            <a href="https://www.instagram.com" target="_blank"><img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/instagram.svg" alt="Instagram"></a>
        </div>
    </div>
</footer>
 <script src="script.js"></script>
</body>
</html>

<?php
$conn->close();
?>
