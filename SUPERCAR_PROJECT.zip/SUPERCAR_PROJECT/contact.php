<?php
include ("Bdconnect.php");

$name = mysqli_real_escape_string($bdd, $_POST["nom"]);
$adresse = mysqli_real_escape_string($bdd, $_POST["adresse"]);
$email = mysqli_real_escape_string($bdd, $_POST["email"]);
$messages = mysqli_real_escape_string($bdd, $_POST["messages"]);

$ajouter = "INSERT INTO contacts (nom, adresse, email, messages) VALUES
('$name', '$adresse', '$email', '$messages')";

mysqli_query($bdd, $ajouter);
mysqli_close($bdd);
?>

<!DOCTYPE HTML>
<html lang="fr">
<head>
<meta charset="UTF-8" />
</head>
<body>
<p>
    <h2 align='center'>Merci. Vos données sont bien insérées !!!</h2>
    <h1><a href="index.html">Retour au menu principal</a></h1>
</p>
</body>
</html>
