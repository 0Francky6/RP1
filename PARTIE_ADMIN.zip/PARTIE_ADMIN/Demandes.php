<?php
session_start();
include("Bdconnect.php");

// Récupération des demandes d'essai
$sql = "SELECT * FROM demandes_essai";
$result = mysqli_query($bdd, $sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Demandes d'essai</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

    <!-- CSS personnalisé -->
    <link rel="stylesheet" href="admin.css">

    <style>
        body { font-family: 'Poppins', sans-serif; }
        .sidebar .nav-link { color: #333; }
        .sidebar .nav-link.active { font-weight: bold; color: #FF6600; }
        .admin-header { background-color: #FF6600; color: white; }
        table img { max-width: 100px; height: auto; }
    </style>
</head>
<body>

<!-- Header -->
<header class="admin-header d-flex justify-content-between align-items-center p-3">
    <h1 class="h3 m-0">Demandes d'essai</h1>
    <a href="logout.php" class="btn btn-danger">Déconnexion</a>
</header>

<div class="container-fluid">
    <div class="row">

        <!-- Sidebar -->
        <aside class="col-md-2 bg-light min-vh-100 p-3 sidebar">
            <ul class="nav flex-column">
                <li class="nav-item"><a class="nav-link" href="index.php">Accueil</a></li>
                <li class="nav-item"><a class="nav-link" href="voitures.php">Voitures</a></li>
                <li class="nav-item"><a class="nav-link active" href="demandes.php">Demandes d'essai</a></li>
                <li class="nav-item"><a class="nav-link" href="services.php">Services</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
            </ul>
        </aside>

        <!-- Main content -->
        <main class="col-md-10 p-4">
            <!-- Notifications -->
            <?php if(isset($_SESSION['message'])): ?>
                <div class="alert alert-<?= $_SESSION['message_type'] ?> alert-dismissible fade show" role="alert">
                    <?= $_SESSION['message'] ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php
                unset($_SESSION['message']);
                unset($_SESSION['message_type']);
                ?>
            <?php endif; ?>

            <?php if(mysqli_num_rows($result) > 0): ?>
                <div class="table-responsive">
                    <table id="demandesTable" class="table table-bordered table-striped align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th>ID</th>
                                <th>Nom</th>
                                <th>Prénom</th>
                                <th>Email</th>
                                <th>Voiture</th>
                                <th>Date d'essai</th>
                                <th>Date de demande</th>
                                <th>Heure</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php while($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['id'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['nom'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['prenom'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['email'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['voiture'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['date_essai'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['date_demande'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['heure'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['statut'] ?? '') ?></td>
                                <td class="d-flex gap-1">
                                    <a href="statut.php?id=<?= $row['id'] ?>&statut=approuvé" class="btn btn-success btn-sm">Approuver</a>
                                    <a href="statut.php?id=<?= $row['id'] ?>&statut=en%20cours" class="btn btn-warning btn-sm">En cours</a>
                                    <a href="statut.php?id=<?= $row['id'] ?>&statut=refusé" class="btn btn-danger btn-sm" onclick="return confirm('Confirmer le refus ?');">Refuser</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p>Aucune demande d'essai pour le moment.</p>
            <?php endif; ?>
        </main>
    </div>
</div>

<!-- Scripts JS -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function() {
    $('#demandesTable').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.13.6/i18n/fr-FR.json"
        },
        "order": [[6, "desc"]] // Tri par date de demande
    });
});
</script>

</body>
</html>
