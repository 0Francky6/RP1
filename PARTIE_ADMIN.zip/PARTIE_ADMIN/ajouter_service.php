<?php
session_start();
include("Bdconnect.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nom = mysqli_real_escape_string($bdd, $_POST['nom']);
    $description = mysqli_real_escape_string($bdd, $_POST['description']);
    $details = mysqli_real_escape_string($bdd, $_POST['details']);

    // Gestion de l'image
    $imageName = '';
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0){
        $imageName = time() . '_' . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], '../IMAGES/' . $imageName);
    }

    $sql = "INSERT INTO service_car (nom, description, details, image)
            VALUES ('$nom', '$description', '$details', '$imageName')";

    if (mysqli_query($bdd, $sql)) {
        $_SESSION['message'] = "✅ Service ajouté avec succès !";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "❌ Erreur : " . mysqli_error($bdd);
        $_SESSION['message_type'] = "danger";
    }

    header("Location: services.php");
    exit();
} else {
    header("Location: services.php");
    exit();
}
?>
