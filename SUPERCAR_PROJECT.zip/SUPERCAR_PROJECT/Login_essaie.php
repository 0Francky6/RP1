<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: " . ($_GET['redirect'] ?? 'demande_essai.php'));  // Redirection après connexion
    exit();
}

include('Bdconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $mot_de_passe = $_POST['mot_de_passe'];

    $sql = "SELECT id FROM utilisateurs WHERE email = '$email' AND mot_de_passe = '$mot_de_passe'";
    $result = $bdd->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $_SESSION['user_id'] = $user['id'];

        // Vérifier s'il y a une redirection en attente
        $redirect = isset($_GET['redirect']) ? $_GET['redirect'] : 'dashboard.php';
        header("Location: $redirect");
        exit();
    } else {
        $error_message = "Identifiants incorrects";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">


  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet" />

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

  <!-- Custom CSS -->
  <link rel="stylesheet" href="styles.css" />
    <title>Connexion</title>
</head>
<body>
 <header class="header">
  <div class="header-left">
    <a href="#" class="logo">SUPERCARS</a>
  </div>

  <!-- Bouton burger -->
  <div class="menu-toggle" id="menu-toggle">
    <i class="fas fa-bars"></i>
  </div>

  <nav class="navbar" id="navbar">
    <a href="index.html">Accueil</a>
    <a href="Voitures.html">Voitures</a>
    <a href="demande_essai.php">Demande d'essai</a>
    <a href="Service.php">Services</a>
    <a href="Contact.html">Contact</a>
  </nav>

  <div class="auth-links">
    <a href="Login.php">Se connecter</a>
    <a href="inscription.html">S'inscrire</a>
  </div>
</header>

<h2>Connexion</h2>
<?php if (isset($error_message)) echo "<p style='color:red;'>$error_message</p>"; ?>

<form action="login.php?redirect=<?php echo $_GET['redirect'] ?? ''; ?>" method="POST">
    <label>Email :</label>
    <input type="email" name="email" required>

    <label>Mot de passe :</label>
    <input type="password" name="mot_de_passe" required>

    <button type="submit">Se connecter</button>
</form>
 <script src="script.js"></script>

</body>
</html>
