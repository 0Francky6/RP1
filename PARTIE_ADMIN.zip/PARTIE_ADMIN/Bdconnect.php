<?php
$host = "localhost";
$login = "root";
$pass = "";
$dbname = "supercar";

// Création de la connexion
$bdd = mysqli_connect($host, $login, $pass, $dbname);

// Vérification de la connexion
if (!$bdd) {
    die("Connexion non réussie à MySQL: " . mysqli_connect_error());
}

// Définir le jeu de caractères en UTF-8
mysqli_set_charset($bdd, "utf8");
?>
