<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?redirect=demande_essai.php");
    exit();
}

include('Bdconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $email = $_POST['email'];
    $voiture = $_POST['voiture'];
    $date_essai = $_POST['date_essai'];
    $heure = $_POST['heure'];
    $sql = "INSERT INTO demandes_essai (nom, prenom, email, voiture, date_essai, date_demande, heure) 
            VALUES ('$nom', '$prenom', '$email', '$voiture', '$date_essai', NOW(),'$heure')";

    if ($bdd->query($sql) === TRUE) {
        $message = "✅ Votre demande a été bien reçue. Nous allons vous envoyer un email de confirmation.";
    } else {
        $message = "❌ Erreur : " . $bdd->error;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="styles.css">
    <title>Demande d'essai - SUPERCARS</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: url('IMAGES/dm.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .main-content {
            flex: 1;
            padding: 40px 8%;
            color: #333;
        }

        .intro-section {
            margin-bottom: 40px;
            text-align: center;
        }

        .intro-section h1 {
            font-size: 2.5rem;
            color: #fff;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
        }

        .intro-section p {
            font-size: 1.1rem;
            color: #eee;
            max-width: 800px;
            margin: 20px auto;
            line-height: 1.6;
        }

        /* Styles du formulaire */
        .container {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            width: 400px;
            box-shadow: 0px 10px 25px rgba(0, 0, 0, 0.2);
            text-align: center;
            color: #333;
            margin: 0 auto;
        }

        h2 {
            font-size: 22px;
            margin-bottom: 15px;
            font-weight: bold;
        }

        .message {
            background: #dfffcf;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-weight: bold;
            color: #3a8b42;
            border-left: 5px solid #3a8b42;
            text-align: left;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        input, select {
            width: 100%;
            padding: 10px;
            border-radius: 8px;
            border: 1px solid rgba(0, 0, 0, 0.2);
            background: rgba(255, 255, 255, 0.8);
            font-size: 16px;
            font-weight: 500;
            outline: none;
            transition: 0.3s;
        }

        input:focus, select:focus {
            border-color: #ff8008;
        }

        button {
            background: linear-gradient(135deg, #ff8008, #ffcc00);
            color: white;
            padding: 12px;
            width: 100%;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            font-size: 18px;
            font-weight: bold;
            transition: 0.3s ease;
            box-shadow: 0px 4px 15px rgba(255, 128, 8, 0.4);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        button:hover {
            transform: scale(1.05);
            box-shadow: 0px 6px 20px rgba(255, 128, 8, 0.6);
        }
    </style>
</head>
<body>
     <header class="header">
  <div class="header-left">
    <a href="#" class="logo">SUPERCARS</a>
  </div>

  <!-- Bouton burger -->
  <div class="menu-toggle" id="menu-toggle">
    <i class="fas fa-bars"></i>
  </div>

  <nav class="navbar" id="navbar">
    <a href="index.html">Accueil</a>
    <a href="Voitures.html">Voitures</a>
    <a href="demande_essai.php">Demande d'essai</a>
    <a href="Service.php">Services</a>
    <a href="Contact.html">Contact</a>
  </nav>

  <div class="auth-links">
    <a href="Login.php">Se connecter</a>
    <a href="inscription.html">S'inscrire</a>
  </div>
</header>
    <main class="main-content">

        <div class="container">
            <?php if (isset($message)) echo "<p class='message'>$message</p>"; ?>

            <h2>Demande d'essai</h2>

            <form action="demande_essai.php" method="POST">
                <input type="text" name="nom" placeholder="Nom" required>
                <input type="text" name="prenom" placeholder="Prénom" required>
                <input type="email" name="email" placeholder="Email" required>

                <select name="voiture" required>
                    <optgroup label="🚀 Mercedes">
                        <option value="AMG GT">AMG GT</option>
                        <option value="CLS 63 MG">CLS 63 MG</option>
                        <option value="Classe G">Classe G</option>
                        <option value="Maybach">Maybach</option>
                    </optgroup>
                    <optgroup label="🏆 Ford">
                        <option value="Ranger Raptor">Ranger Raptor</option>
                        <option value="F-150">F-150</option>
                        <option value="Focus">Focus</option>
                        <option value="Explorer">Explorer</option>
                    </optgroup>
                    <optgroup label="🔥 Toyota">
                        <option value="Corolla">Corolla</option>
                        <option value="RAV4">RAV4</option>
                        <option value="Camry">Camry</option>
                    </optgroup>
                    <optgroup label="⚡ Nissan">
                        <option value="GTR">GTR</option>
                        <option value="Magnite">Magnite</option>
                        <option value="X-Trail">X-Trail</option>
                        <option value="Qashqai">Qashqai</option>
                    </optgroup>
                </select>

                <input type="date" name="date_essai" required>
                <input type="time" name="heure" placeholder="Heure" required>

                <button type="submit">📩 Envoyer la demande</button>
            </form>
        </div>
    </main>

    
  <footer>
    <div class="footer-bottom">
        <p>&copy; 2025-2028 Supercars.fr — Tous droits réservés. Réalisation & design MCCI SIO.</p>
        <a href="Mentions.html">Mentions légales</a>
        <a href="politique.html">Politique de confidentialité</a>
        <a href="conditions.html">Conditions générales</a>
    </div>

    <!-- Section Suivez-nous déplacée sous le footer-bottom -->
    <div class="footer-section socials-bottom">
        <h3>Suivez-nous</h3>
        <div class="socials">
            <a href="https://www.facebook.com" target="_blank"><img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/facebook.svg" alt="Facebook" /></a>
            <a href="https://www.twitter.com" target="_blank"><img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/twitter.svg" alt="Twitter" /></a>
            <a href="https://www.instagram.com" target="_blank"><img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/instagram.svg" alt="Instagram" /></a>
        </div>
    </div>
</footer>
 <script src="script.js"></script>

</body>
</html>