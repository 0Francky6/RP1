<?php
session_start();
include("Bdconnect.php");

// Récupération de tous les services
$services = mysqli_query($bdd, "SELECT * FROM service_car");
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Admin - Services</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">

    <link rel="stylesheet" href="admin.css">

    <style>
        body { font-family: 'Poppins', sans-serif; }
        .sidebar .nav-link { color: #333; }
        .sidebar .nav-link.active { font-weight: bold; color: #FF6600; }
        .admin-header { background-color: #FF6600; color: white; }
        table img { max-width: 100px; }
        @media (max-width: 768px) {
            .sidebar { position: fixed; top: 56px; left: -250px; width: 250px; z-index: 1040; transition: 0.3s; }
            .sidebar.show { left: 0; }
        }
    </style>
</head>
<body>

<header class="admin-header d-flex justify-content-between align-items-center p-3">
    <h1 class="h3 m-0">Gestion des Services</h1>
    <div>
        <button class="btn btn-light d-md-none" id="sidebarToggle">☰</button>
        <a href="logout.php" class="btn btn-danger">Déconnexion</a>
    </div>
</header>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <aside class="col-md-2 bg-light min-vh-100 p-3 sidebar">
            <ul class="nav flex-column">
                <li class="nav-item"><a class="nav-link" href="index.php">Accueil</a></li>
                <li class="nav-item"><a class="nav-link" href="voitures.php">Voitures</a></li>
                <li class="nav-item"><a class="nav-link" href="Demandes.php">Demandes d'essai</a></li>
                <li class="nav-item"><a class="nav-link active" href="admin_services.php">Services</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
            </ul>
        </aside>

        <!-- Main content -->
        <main class="col-md-10 p-4">

            <?php if(isset($_SESSION['message'])): ?>
                <div class="alert alert-<?= $_SESSION['message_type'] ?? 'success' ?> alert-dismissible fade show" role="alert">
                    <?= $_SESSION['message'] ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['message'], $_SESSION['message_type']); ?>
            <?php endif; ?>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Liste des Services</h2>
                <button class="btn btn-success btn-lg" data-bs-toggle="modal" data-bs-target="#modalAjouterService">➕ Ajouter un Service</button>
            </div>

            <div class="table-responsive">
                <table id="servicesTable" class="table table-bordered table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Nom</th>
                            <th>Image</th>
                            <th>Description</th>
                            <th>Détails</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($service = mysqli_fetch_assoc($services)): ?>
                            <tr>
                                <td><?= $service['id'] ?></td>
                                <td><?= htmlspecialchars($service['nom']) ?></td>
                                <td><img src="../IMAGES/<?= $service['image'] ?>" alt="<?= $service['nom'] ?>"></td>
                                <td><?= htmlspecialchars($service['description']) ?></td>
                                <td><?= nl2br(htmlspecialchars($service['details'])) ?></td>
                                <td class="d-flex gap-2">
                                    <!-- Modifier en modal -->
                                    <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modalModifierService<?= $service['id'] ?>">Modifier</button>

                                    <!-- Modal Modification -->
                                    <div class="modal fade" id="modalModifierService<?= $service['id'] ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered modal-lg">
                                            <div class="modal-content">
                                                <form method="post" action="modifier_service.php" enctype="multipart/form-data">
                                                    <div class="modal-header bg-warning text-dark">
                                                        <h5 class="modal-title">Modifier le service</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <input type="hidden" name="id" value="<?= $service['id'] ?>">
                                                        <input type="hidden" name="old_image" value="<?= $service['image'] ?>">
                                                        <div class="mb-3">
                                                            <label class="form-label">Nom</label>
                                                            <input type="text" name="nom" class="form-control" value="<?= htmlspecialchars($service['nom']) ?>" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label">Description</label>
                                                            <textarea name="description" class="form-control" rows="3" required><?= htmlspecialchars($service['description']) ?></textarea>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label">Détails</label>
                                                            <textarea name="details" class="form-control" rows="3"><?= htmlspecialchars($service['details']) ?></textarea>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label">Image</label>
                                                            <input type="file" name="image" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                                                        <button type="submit" class="btn btn-warning">Enregistrer</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Supprimer -->
                                    <a href="supprimer_service.php?id=<?= $service['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Voulez-vous vraiment supprimer ce service ?');">Supprimer</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

        </main>
    </div>
</div>

<!-- Modal Ajouter Service -->
<div class="modal fade" id="modalAjouterService" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <form method="post" action="ajouter_service.php" enctype="multipart/form-data">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title">Ajouter un Service</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Nom</label>
                        <input type="text" name="nom" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Détails</label>
                        <textarea name="details" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Image</label>
                        <input type="file" name="image" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                    <button type="submit" class="btn btn-success">Ajouter</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    $(document).ready(function() {
        $('#servicesTable').DataTable();
    });

    // Toggle sidebar mobile
    document.getElementById('sidebarToggle').addEventListener('click', function() {
        document.getElementById('sidebar').classList.toggle('show');
    });
